import getRect from '../../src/utils/getBoundingClientRect';
export default getRect;
